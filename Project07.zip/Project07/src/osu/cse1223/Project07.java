/*
 * Project07.java
 * 
 *   A program that plays the dice game high/low
 *   Used to practice breaking code up into methods. 
 * 
 * @author Kelland Goodin 
 * @version 20181008 
 * 
 */
package osu.cse1223;

import java.util.Scanner;

public class Project07 {


	public static void main(String[] args) {
		// Fill in the body
		Scanner inScanner = new Scanner(System.in);
		int maxBet = 100;
		int userBet;
		char ch; 
		int roll1;
		int roll2;
		int winlose; 

		while(maxBet > 0) { 
		System.out.println("You have " + maxBet + "  dollars. ");
		userBet = getBet(inScanner, maxBet);
		if(userBet == 0) {
			break;
		}
		if(userBet != 0) {
		ch = getHighLow(inScanner);
		roll1 = getRoll(); 
		System.out.println("Die 1 rolls : " + roll1);
		roll2 = getRoll(); 
		System.out.println("Die 2 rolls : " + roll2);
		System.out.println("Total of two dice is: " + (roll1 + roll2)); 
		winlose = determineWinnings(ch, userBet, roll1 + roll2);
		if (winlose >= 0) {
			System.out.println("You won " + winlose + " dollars! ");
	        }
        else {
            System.out.println("You Lost!");
        }
		maxBet = maxBet + winlose;
		}
	}
		System.out.println("Goodbye!");
		}
	// Given a Scanner and a current maximum amount of money, prompt the user for
	// an integer representing the number of dollars that they want to bet.  This
	// number must be between 0 and to maximum number of dollars.  If the user enters
	// a number that is out of bounds, display an error message and ask again.
	// Return the bet to the calling program.
	 
	private static int getBet(Scanner inScanner, int currentPool) {
		// Fill in the body
		int bet;

        do {
            System.out.println("Enter an amount to bet (0 to quit): ");
            bet = inScanner.nextInt();
            while(bet > currentPool || bet < 0) {
            	System.out.println("Your bet MUST be between 0 and 100 dollars");
            	System.out.println("Enter an amount to bet (0 to quit): ");
                bet = inScanner.nextInt();
            	}
            if(bet == 0) {
               System.out.println("");
            	break;
            }
           } while (bet > currentPool && bet != 0);
        while(bet > currentPool) {System.out.println("Your bet MUST be between 0 and 100 dollars");}

        return bet;
	}
	
	// Given a Scanner, prompt the user for a single character indicating whether they
	// would like to bet High ('H'), Low ('L') or Sevens ('S').  Your code should accept
	// either capital or lowercase answers, but should display an error if the user attempts
	// to enter anything but one of these 3 values and prompt for a valid answer.
	// Return the character to the calling program.
	
	private static char getHighLow(Scanner inScanner) {
		// Fill in the body
		 System.out.println("High, low or sevens (H/L/S): ");
	     String str = inScanner.next();
	
	        return str.charAt(0);
	}
	
	// Produce a random roll of a single six-sided die and return that value to the calling
	// program
	
	private static int getRoll() {
		// Fill in the body
		int roll = (int)(Math.random()*6) + 1;
		
		return roll; 
	}
	
	// Given the choice of high, low or sevens, the player's bet and the total result of
	// the roll of the dice, determine how much the player has won.  If the player loses
	// the bet then winnings should be negative.  If the player wins, the winnings should
	// be equal to the bet if the choice is High or Low and 4 times the bet if the choice
	// was Sevens.  Return the winnings to the calling program.
	
	private static int determineWinnings(char highLow, int userBet, int roll) {
		// Fill in the body
	   int gains = 0; 
	   
	   if(highLow == 'H' || highLow == 'h') {
		   if(roll <= 7) {
			  gains = 0 - userBet;
			  }
			  else {
				  gains = userBet; 
			  }   
	   }
	   if(highLow == 'L' || highLow == 'l') {
				   if(roll <= 7) {
					 // gains = 0 - userBet;
					   gains = userBet; 
					  }
					  else {
						 // gains = userBet; 
						  gains = 0 - userBet;
			 }	
	   }
	   if(highLow == 'S' || highLow == 's') {
					   if(roll == 7) {
						  gains = 4 * userBet;
						  } 
						  else {
							  gains = 0 - userBet; 
						  }	  	   
		   }
	   return gains; 
}
}